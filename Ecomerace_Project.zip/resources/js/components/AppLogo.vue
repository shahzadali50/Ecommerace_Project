<script setup lang="ts">
// import AppLogoIcon from '@/components/AppLogoIcon.vue';
</script>

<template>
    <!-- <div class="flex aspect-square size-8 items-center justify-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground">
        <AppLogoIcon class="size-5 fill-current text-white dark:text-black" />
    </div> -->
    <div class="ml-1 grid flex-1 text-left text-sm">
        <img class="w-[160px]" src="/assets/images/Logo-LaCuna-JP-azul.fw.png" alt="Logo LaCuna" />

        <!-- <span class="mb-0.5 truncate font-semibold leading-none">LaCuna-Marketplace</span> -->
    </div>
</template>
