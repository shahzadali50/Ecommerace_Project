<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', subject: app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>
            <!-- ✅ Favicon -->
        <link rel="icon" type="image/webp" href="<?php echo e(asset('assets/images/favicon.webp')); ?>" />
         <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/customAdmin.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/color.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/customFrontend.css')); ?>">
        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.ts']); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>

    </body>
</html>
<?php /**PATH E:\shahzad\laravel\Ecommerace_Project\resources\views/app.blade.php ENDPATH**/ ?>